/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
? [2024] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA1 aliases
#define SWA_TRIS                 TRISAbits.TRISA1
#define SWA_LAT                  LATAbits.LATA1
#define SWA_PORT                 PORTAbits.RA1
#define SWA_WPU                  WPUAbits.WPUA1
#define SWA_OD                   ODCONAbits.ODCA1
#define SWA_ANS                  ANSELAbits.ANSELA1
#define SWA_SetHigh()            do { LATAbits.LATA1 = 1; } while(0)
#define SWA_SetLow()             do { LATAbits.LATA1 = 0; } while(0)
#define SWA_Toggle()             do { LATAbits.LATA1 = ~LATAbits.LATA1; } while(0)
#define SWA_GetValue()           PORTAbits.RA1
#define SWA_SetDigitalInput()    do { TRISAbits.TRISA1 = 1; } while(0)
#define SWA_SetDigitalOutput()   do { TRISAbits.TRISA1 = 0; } while(0)
#define SWA_SetPullup()          do { WPUAbits.WPUA1 = 1; } while(0)
#define SWA_ResetPullup()        do { WPUAbits.WPUA1 = 0; } while(0)
#define SWA_SetPushPull()        do { ODCONAbits.ODCA1 = 0; } while(0)
#define SWA_SetOpenDrain()       do { ODCONAbits.ODCA1 = 1; } while(0)
#define SWA_SetAnalogMode()      do { ANSELAbits.ANSELA1 = 1; } while(0)
#define SWA_SetDigitalMode()     do { ANSELAbits.ANSELA1 = 0; } while(0)

// get/set RA2 aliases
#define SWB_TRIS                 TRISAbits.TRISA2
#define SWB_LAT                  LATAbits.LATA2
#define SWB_PORT                 PORTAbits.RA2
#define SWB_WPU                  WPUAbits.WPUA2
#define SWB_OD                   ODCONAbits.ODCA2
#define SWB_ANS                  ANSELAbits.ANSELA2
#define SWB_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define SWB_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define SWB_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define SWB_GetValue()           PORTAbits.RA2
#define SWB_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define SWB_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define SWB_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define SWB_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define SWB_SetPushPull()        do { ODCONAbits.ODCA2 = 0; } while(0)
#define SWB_SetOpenDrain()       do { ODCONAbits.ODCA2 = 1; } while(0)
#define SWB_SetAnalogMode()      do { ANSELAbits.ANSELA2 = 1; } while(0)
#define SWB_SetDigitalMode()     do { ANSELAbits.ANSELA2 = 0; } while(0)

// get/set RA5 aliases
#define SWD_TRIS                 TRISAbits.TRISA5
#define SWD_LAT                  LATAbits.LATA5
#define SWD_PORT                 PORTAbits.RA5
#define SWD_WPU                  WPUAbits.WPUA5
#define SWD_OD                   ODCONAbits.ODCA5
#define SWD_ANS                  ANSELAbits.ANSELA5
#define SWD_SetHigh()            do { LATAbits.LATA5 = 1; } while(0)
#define SWD_SetLow()             do { LATAbits.LATA5 = 0; } while(0)
#define SWD_Toggle()             do { LATAbits.LATA5 = ~LATAbits.LATA5; } while(0)
#define SWD_GetValue()           PORTAbits.RA5
#define SWD_SetDigitalInput()    do { TRISAbits.TRISA5 = 1; } while(0)
#define SWD_SetDigitalOutput()   do { TRISAbits.TRISA5 = 0; } while(0)
#define SWD_SetPullup()          do { WPUAbits.WPUA5 = 1; } while(0)
#define SWD_ResetPullup()        do { WPUAbits.WPUA5 = 0; } while(0)
#define SWD_SetPushPull()        do { ODCONAbits.ODCA5 = 0; } while(0)
#define SWD_SetOpenDrain()       do { ODCONAbits.ODCA5 = 1; } while(0)
#define SWD_SetAnalogMode()      do { ANSELAbits.ANSELA5 = 1; } while(0)
#define SWD_SetDigitalMode()     do { ANSELAbits.ANSELA5 = 0; } while(0)

// get/set RB0 aliases
#define IO_RB0_TRIS                 TRISBbits.TRISB0
#define IO_RB0_LAT                  LATBbits.LATB0
#define IO_RB0_PORT                 PORTBbits.RB0
#define IO_RB0_WPU                  WPUBbits.WPUB0
#define IO_RB0_OD                   ODCONBbits.ODCB0
#define IO_RB0_ANS                  ANSELBbits.ANSELB0
#define IO_RB0_SetHigh()            do { LATBbits.LATB0 = 1; } while(0)
#define IO_RB0_SetLow()             do { LATBbits.LATB0 = 0; } while(0)
#define IO_RB0_Toggle()             do { LATBbits.LATB0 = ~LATBbits.LATB0; } while(0)
#define IO_RB0_GetValue()           PORTBbits.RB0
#define IO_RB0_SetDigitalInput()    do { TRISBbits.TRISB0 = 1; } while(0)
#define IO_RB0_SetDigitalOutput()   do { TRISBbits.TRISB0 = 0; } while(0)
#define IO_RB0_SetPullup()          do { WPUBbits.WPUB0 = 1; } while(0)
#define IO_RB0_ResetPullup()        do { WPUBbits.WPUB0 = 0; } while(0)
#define IO_RB0_SetPushPull()        do { ODCONBbits.ODCB0 = 0; } while(0)
#define IO_RB0_SetOpenDrain()       do { ODCONBbits.ODCB0 = 1; } while(0)
#define IO_RB0_SetAnalogMode()      do { ANSELBbits.ANSELB0 = 1; } while(0)
#define IO_RB0_SetDigitalMode()     do { ANSELBbits.ANSELB0 = 0; } while(0)

// get/set RB1 aliases
#define IO_RB1_TRIS                 TRISBbits.TRISB1
#define IO_RB1_LAT                  LATBbits.LATB1
#define IO_RB1_PORT                 PORTBbits.RB1
#define IO_RB1_WPU                  WPUBbits.WPUB1
#define IO_RB1_OD                   ODCONBbits.ODCB1
#define IO_RB1_ANS                  ANSELBbits.ANSELB1
#define IO_RB1_SetHigh()            do { LATBbits.LATB1 = 1; } while(0)
#define IO_RB1_SetLow()             do { LATBbits.LATB1 = 0; } while(0)
#define IO_RB1_Toggle()             do { LATBbits.LATB1 = ~LATBbits.LATB1; } while(0)
#define IO_RB1_GetValue()           PORTBbits.RB1
#define IO_RB1_SetDigitalInput()    do { TRISBbits.TRISB1 = 1; } while(0)
#define IO_RB1_SetDigitalOutput()   do { TRISBbits.TRISB1 = 0; } while(0)
#define IO_RB1_SetPullup()          do { WPUBbits.WPUB1 = 1; } while(0)
#define IO_RB1_ResetPullup()        do { WPUBbits.WPUB1 = 0; } while(0)
#define IO_RB1_SetPushPull()        do { ODCONBbits.ODCB1 = 0; } while(0)
#define IO_RB1_SetOpenDrain()       do { ODCONBbits.ODCB1 = 1; } while(0)
#define IO_RB1_SetAnalogMode()      do { ANSELBbits.ANSELB1 = 1; } while(0)
#define IO_RB1_SetDigitalMode()     do { ANSELBbits.ANSELB1 = 0; } while(0)

// get/set RB2 aliases
#define IO_RB2_TRIS                 TRISBbits.TRISB2
#define IO_RB2_LAT                  LATBbits.LATB2
#define IO_RB2_PORT                 PORTBbits.RB2
#define IO_RB2_WPU                  WPUBbits.WPUB2
#define IO_RB2_OD                   ODCONBbits.ODCB2
#define IO_RB2_ANS                  ANSELBbits.ANSELB2
#define IO_RB2_SetHigh()            do { LATBbits.LATB2 = 1; } while(0)
#define IO_RB2_SetLow()             do { LATBbits.LATB2 = 0; } while(0)
#define IO_RB2_Toggle()             do { LATBbits.LATB2 = ~LATBbits.LATB2; } while(0)
#define IO_RB2_GetValue()           PORTBbits.RB2
#define IO_RB2_SetDigitalInput()    do { TRISBbits.TRISB2 = 1; } while(0)
#define IO_RB2_SetDigitalOutput()   do { TRISBbits.TRISB2 = 0; } while(0)
#define IO_RB2_SetPullup()          do { WPUBbits.WPUB2 = 1; } while(0)
#define IO_RB2_ResetPullup()        do { WPUBbits.WPUB2 = 0; } while(0)
#define IO_RB2_SetPushPull()        do { ODCONBbits.ODCB2 = 0; } while(0)
#define IO_RB2_SetOpenDrain()       do { ODCONBbits.ODCB2 = 1; } while(0)
#define IO_RB2_SetAnalogMode()      do { ANSELBbits.ANSELB2 = 1; } while(0)
#define IO_RB2_SetDigitalMode()     do { ANSELBbits.ANSELB2 = 0; } while(0)

// get/set RB3 aliases
#define SWC_TRIS                 TRISBbits.TRISB3
#define SWC_LAT                  LATBbits.LATB3
#define SWC_PORT                 PORTBbits.RB3
#define SWC_WPU                  WPUBbits.WPUB3
#define SWC_OD                   ODCONBbits.ODCB3
#define SWC_ANS                  ANSELBbits.ANSELB3
#define SWC_SetHigh()            do { LATBbits.LATB3 = 1; } while(0)
#define SWC_SetLow()             do { LATBbits.LATB3 = 0; } while(0)
#define SWC_Toggle()             do { LATBbits.LATB3 = ~LATBbits.LATB3; } while(0)
#define SWC_GetValue()           PORTBbits.RB3
#define SWC_SetDigitalInput()    do { TRISBbits.TRISB3 = 1; } while(0)
#define SWC_SetDigitalOutput()   do { TRISBbits.TRISB3 = 0; } while(0)
#define SWC_SetPullup()          do { WPUBbits.WPUB3 = 1; } while(0)
#define SWC_ResetPullup()        do { WPUBbits.WPUB3 = 0; } while(0)
#define SWC_SetPushPull()        do { ODCONBbits.ODCB3 = 0; } while(0)
#define SWC_SetOpenDrain()       do { ODCONBbits.ODCB3 = 1; } while(0)
#define SWC_SetAnalogMode()      do { ANSELBbits.ANSELB3 = 1; } while(0)
#define SWC_SetDigitalMode()     do { ANSELBbits.ANSELB3 = 0; } while(0)

// get/set RB5 aliases
#define SWCNT_TRIS                 TRISBbits.TRISB5
#define SWCNT_LAT                  LATBbits.LATB5
#define SWCNT_PORT                 PORTBbits.RB5
#define SWCNT_WPU                  WPUBbits.WPUB5
#define SWCNT_OD                   ODCONBbits.ODCB5
#define SWCNT_ANS                  ANSELBbits.ANSELB5
#define SWCNT_SetHigh()            do { LATBbits.LATB5 = 1; } while(0)
#define SWCNT_SetLow()             do { LATBbits.LATB5 = 0; } while(0)
#define SWCNT_Toggle()             do { LATBbits.LATB5 = ~LATBbits.LATB5; } while(0)
#define SWCNT_GetValue()           PORTBbits.RB5
#define SWCNT_SetDigitalInput()    do { TRISBbits.TRISB5 = 1; } while(0)
#define SWCNT_SetDigitalOutput()   do { TRISBbits.TRISB5 = 0; } while(0)
#define SWCNT_SetPullup()          do { WPUBbits.WPUB5 = 1; } while(0)
#define SWCNT_ResetPullup()        do { WPUBbits.WPUB5 = 0; } while(0)
#define SWCNT_SetPushPull()        do { ODCONBbits.ODCB5 = 0; } while(0)
#define SWCNT_SetOpenDrain()       do { ODCONBbits.ODCB5 = 1; } while(0)
#define SWCNT_SetAnalogMode()      do { ANSELBbits.ANSELB5 = 1; } while(0)
#define SWCNT_SetDigitalMode()     do { ANSELBbits.ANSELB5 = 0; } while(0)

// get/set RD0 aliases
#define SW3_TRIS                 TRISDbits.TRISD0
#define SW3_LAT                  LATDbits.LATD0
#define SW3_PORT                 PORTDbits.RD0
#define SW3_WPU                  WPUDbits.WPUD0
#define SW3_OD                   ODCONDbits.ODCD0
#define SW3_ANS                  ANSELDbits.ANSELD0
#define SW3_SetHigh()            do { LATDbits.LATD0 = 1; } while(0)
#define SW3_SetLow()             do { LATDbits.LATD0 = 0; } while(0)
#define SW3_Toggle()             do { LATDbits.LATD0 = ~LATDbits.LATD0; } while(0)
#define SW3_GetValue()           PORTDbits.RD0
#define SW3_SetDigitalInput()    do { TRISDbits.TRISD0 = 1; } while(0)
#define SW3_SetDigitalOutput()   do { TRISDbits.TRISD0 = 0; } while(0)
#define SW3_SetPullup()          do { WPUDbits.WPUD0 = 1; } while(0)
#define SW3_ResetPullup()        do { WPUDbits.WPUD0 = 0; } while(0)
#define SW3_SetPushPull()        do { ODCONDbits.ODCD0 = 0; } while(0)
#define SW3_SetOpenDrain()       do { ODCONDbits.ODCD0 = 1; } while(0)
#define SW3_SetAnalogMode()      do { ANSELDbits.ANSELD0 = 1; } while(0)
#define SW3_SetDigitalMode()     do { ANSELDbits.ANSELD0 = 0; } while(0)

// get/set RD1 aliases
#define SW4_TRIS                 TRISDbits.TRISD1
#define SW4_LAT                  LATDbits.LATD1
#define SW4_PORT                 PORTDbits.RD1
#define SW4_WPU                  WPUDbits.WPUD1
#define SW4_OD                   ODCONDbits.ODCD1
#define SW4_ANS                  ANSELDbits.ANSELD1
#define SW4_SetHigh()            do { LATDbits.LATD1 = 1; } while(0)
#define SW4_SetLow()             do { LATDbits.LATD1 = 0; } while(0)
#define SW4_Toggle()             do { LATDbits.LATD1 = ~LATDbits.LATD1; } while(0)
#define SW4_GetValue()           PORTDbits.RD1
#define SW4_SetDigitalInput()    do { TRISDbits.TRISD1 = 1; } while(0)
#define SW4_SetDigitalOutput()   do { TRISDbits.TRISD1 = 0; } while(0)
#define SW4_SetPullup()          do { WPUDbits.WPUD1 = 1; } while(0)
#define SW4_ResetPullup()        do { WPUDbits.WPUD1 = 0; } while(0)
#define SW4_SetPushPull()        do { ODCONDbits.ODCD1 = 0; } while(0)
#define SW4_SetOpenDrain()       do { ODCONDbits.ODCD1 = 1; } while(0)
#define SW4_SetAnalogMode()      do { ANSELDbits.ANSELD1 = 1; } while(0)
#define SW4_SetDigitalMode()     do { ANSELDbits.ANSELD1 = 0; } while(0)

// get/set RD2 aliases
#define LED1_TRIS                 TRISDbits.TRISD2
#define LED1_LAT                  LATDbits.LATD2
#define LED1_PORT                 PORTDbits.RD2
#define LED1_WPU                  WPUDbits.WPUD2
#define LED1_OD                   ODCONDbits.ODCD2
#define LED1_ANS                  ANSELDbits.ANSELD2
#define LED1_SetHigh()            do { LATDbits.LATD2 = 1; } while(0)
#define LED1_SetLow()             do { LATDbits.LATD2 = 0; } while(0)
#define LED1_Toggle()             do { LATDbits.LATD2 = ~LATDbits.LATD2; } while(0)
#define LED1_GetValue()           PORTDbits.RD2
#define LED1_SetDigitalInput()    do { TRISDbits.TRISD2 = 1; } while(0)
#define LED1_SetDigitalOutput()   do { TRISDbits.TRISD2 = 0; } while(0)
#define LED1_SetPullup()          do { WPUDbits.WPUD2 = 1; } while(0)
#define LED1_ResetPullup()        do { WPUDbits.WPUD2 = 0; } while(0)
#define LED1_SetPushPull()        do { ODCONDbits.ODCD2 = 0; } while(0)
#define LED1_SetOpenDrain()       do { ODCONDbits.ODCD2 = 1; } while(0)
#define LED1_SetAnalogMode()      do { ANSELDbits.ANSELD2 = 1; } while(0)
#define LED1_SetDigitalMode()     do { ANSELDbits.ANSELD2 = 0; } while(0)

// get/set RD3 aliases
#define LED2_TRIS                 TRISDbits.TRISD3
#define LED2_LAT                  LATDbits.LATD3
#define LED2_PORT                 PORTDbits.RD3
#define LED2_WPU                  WPUDbits.WPUD3
#define LED2_OD                   ODCONDbits.ODCD3
#define LED2_ANS                  ANSELDbits.ANSELD3
#define LED2_SetHigh()            do { LATDbits.LATD3 = 1; } while(0)
#define LED2_SetLow()             do { LATDbits.LATD3 = 0; } while(0)
#define LED2_Toggle()             do { LATDbits.LATD3 = ~LATDbits.LATD3; } while(0)
#define LED2_GetValue()           PORTDbits.RD3
#define LED2_SetDigitalInput()    do { TRISDbits.TRISD3 = 1; } while(0)
#define LED2_SetDigitalOutput()   do { TRISDbits.TRISD3 = 0; } while(0)
#define LED2_SetPullup()          do { WPUDbits.WPUD3 = 1; } while(0)
#define LED2_ResetPullup()        do { WPUDbits.WPUD3 = 0; } while(0)
#define LED2_SetPushPull()        do { ODCONDbits.ODCD3 = 0; } while(0)
#define LED2_SetOpenDrain()       do { ODCONDbits.ODCD3 = 1; } while(0)
#define LED2_SetAnalogMode()      do { ANSELDbits.ANSELD3 = 1; } while(0)
#define LED2_SetDigitalMode()     do { ANSELDbits.ANSELD3 = 0; } while(0)

// get/set RF4 aliases
#define LED3_TRIS                 TRISFbits.TRISF4
#define LED3_LAT                  LATFbits.LATF4
#define LED3_PORT                 PORTFbits.RF4
#define LED3_WPU                  WPUFbits.WPUF4
#define LED3_OD                   ODCONFbits.ODCF4
#define LED3_ANS                  ANSELFbits.ANSELF4
#define LED3_SetHigh()            do { LATFbits.LATF4 = 1; } while(0)
#define LED3_SetLow()             do { LATFbits.LATF4 = 0; } while(0)
#define LED3_Toggle()             do { LATFbits.LATF4 = ~LATFbits.LATF4; } while(0)
#define LED3_GetValue()           PORTFbits.RF4
#define LED3_SetDigitalInput()    do { TRISFbits.TRISF4 = 1; } while(0)
#define LED3_SetDigitalOutput()   do { TRISFbits.TRISF4 = 0; } while(0)
#define LED3_SetPullup()          do { WPUFbits.WPUF4 = 1; } while(0)
#define LED3_ResetPullup()        do { WPUFbits.WPUF4 = 0; } while(0)
#define LED3_SetPushPull()        do { ODCONFbits.ODCF4 = 0; } while(0)
#define LED3_SetOpenDrain()       do { ODCONFbits.ODCF4 = 1; } while(0)
#define LED3_SetAnalogMode()      do { ANSELFbits.ANSELF4 = 1; } while(0)
#define LED3_SetDigitalMode()     do { ANSELFbits.ANSELF4 = 0; } while(0)

// get/set RF5 aliases
#define LED4_TRIS                 TRISFbits.TRISF5
#define LED4_LAT                  LATFbits.LATF5
#define LED4_PORT                 PORTFbits.RF5
#define LED4_WPU                  WPUFbits.WPUF5
#define LED4_OD                   ODCONFbits.ODCF5
#define LED4_ANS                  ANSELFbits.ANSELF5
#define LED4_SetHigh()            do { LATFbits.LATF5 = 1; } while(0)
#define LED4_SetLow()             do { LATFbits.LATF5 = 0; } while(0)
#define LED4_Toggle()             do { LATFbits.LATF5 = ~LATFbits.LATF5; } while(0)
#define LED4_GetValue()           PORTFbits.RF5
#define LED4_SetDigitalInput()    do { TRISFbits.TRISF5 = 1; } while(0)
#define LED4_SetDigitalOutput()   do { TRISFbits.TRISF5 = 0; } while(0)
#define LED4_SetPullup()          do { WPUFbits.WPUF5 = 1; } while(0)
#define LED4_ResetPullup()        do { WPUFbits.WPUF5 = 0; } while(0)
#define LED4_SetPushPull()        do { ODCONFbits.ODCF5 = 0; } while(0)
#define LED4_SetOpenDrain()       do { ODCONFbits.ODCF5 = 1; } while(0)
#define LED4_SetAnalogMode()      do { ANSELFbits.ANSELF5 = 1; } while(0)
#define LED4_SetDigitalMode()     do { ANSELFbits.ANSELF5 = 0; } while(0)

// get/set RF7 aliases
#define IO_RF7_TRIS                 TRISFbits.TRISF7
#define IO_RF7_LAT                  LATFbits.LATF7
#define IO_RF7_PORT                 PORTFbits.RF7
#define IO_RF7_WPU                  WPUFbits.WPUF7
#define IO_RF7_OD                   ODCONFbits.ODCF7
#define IO_RF7_ANS                  ANSELFbits.ANSELF7
#define IO_RF7_SetHigh()            do { LATFbits.LATF7 = 1; } while(0)
#define IO_RF7_SetLow()             do { LATFbits.LATF7 = 0; } while(0)
#define IO_RF7_Toggle()             do { LATFbits.LATF7 = ~LATFbits.LATF7; } while(0)
#define IO_RF7_GetValue()           PORTFbits.RF7
#define IO_RF7_SetDigitalInput()    do { TRISFbits.TRISF7 = 1; } while(0)
#define IO_RF7_SetDigitalOutput()   do { TRISFbits.TRISF7 = 0; } while(0)
#define IO_RF7_SetPullup()          do { WPUFbits.WPUF7 = 1; } while(0)
#define IO_RF7_ResetPullup()        do { WPUFbits.WPUF7 = 0; } while(0)
#define IO_RF7_SetPushPull()        do { ODCONFbits.ODCF7 = 0; } while(0)
#define IO_RF7_SetOpenDrain()       do { ODCONFbits.ODCF7 = 1; } while(0)
#define IO_RF7_SetAnalogMode()      do { ANSELFbits.ANSELF7 = 1; } while(0)
#define IO_RF7_SetDigitalMode()     do { ANSELFbits.ANSELF7 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/